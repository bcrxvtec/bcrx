import xbmcaddon

MainBase = 'https://pastebin.com/raw/RUs0JP5g'
addon = xbmcaddon.Addon('plugin.video.bcrx')